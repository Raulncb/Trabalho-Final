<?php
//sem segurança

include_once "../servico/Bd.php";

?>
<!doctype html>
<html>
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Poema Sem Dedicação</title>

    <style>
      .fixedHeightImg > img {
       max-height: 400px;
       margin-left: auto;
       margin-right: auto;
       width: auto;
    }
      </style>
  </head>
  <body>
    

<div class="container" style="background-color:white"> 

<div class="row">
    <div class="col-2 col-sm-2 col-md-2" style="background-color:#826951">
  
 <img src="https://www.institutoclaro.org.br/educacao/wp-content/uploads/sites/2/2012/02/Plano-de-aula-G%C3%AAnero-poesia-topo.jpg" width = "120%">
      
      </div>
    
    
    <div class="col" style="background-color:#826951">
     
  <h1 style="color:white">Poema Sem Dedicação! (PSD)</h1>
    </div>
    <div class="col" style="background-color:#826951">
    
      <input type="text" class="form-control" placeholder="O que você procura?">
      <button type="submit" class="btn btn-light ">Buscar</button>
     
    </div>
</div>




<hr>




<nav>
       <a type="button" style="background-color:#826951" class="btn btn-secondary">Início</a>
       <a type="button" href="https://raulhtml5.000webhostapp.com/20202/3006/index.html" style="background-color:#826951" class="btn btn-secondary">Login</a>
       
      </nav>
<hr>
      <br><br>
      
    <div class="row">
      <?php
        
           $bd = new Bd();
           $sql = "select * from blog";
          
           
           foreach ($bd->query($sql) as $row) {?>
    <div class="col-4 d-flex justify-content-center align-items-center">       
        <div class="card" style="width: 18rem;">
            <div class="card-body">
                
              <h5 class="card-title"><?php echo $row['titulo']?></h5>
                 <p class="card-text"><?php echo $row['corpo']?></p>
    
            </div>
        </div>
    </div>
<?php }?>

    
  </div>
</div>
      

</div>






    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>





    </body>
  </html>