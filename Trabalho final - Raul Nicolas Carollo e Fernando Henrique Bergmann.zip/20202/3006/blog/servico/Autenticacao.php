<?php
session_start();

if ( ! isset($_SESSION["autenticado"]) ){
    echo "
    <script>
    window.location.replace('https://raulhtml5.000webhostapp.com/20202/3006');
    </script>
    ";
    
}

?>