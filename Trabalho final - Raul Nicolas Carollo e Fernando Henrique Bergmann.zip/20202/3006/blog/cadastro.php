<?php 

$host = "localhost";
$usuario = "id14808142_teste1";
$senha = "N<wU6g\pRZ}eb(O1";
$bd="id14808142_teste";



$link = new mysqli($host, $usuario, $senha, $bd);


if($link -> connect_errno) {
    echo "Falha na conexão: (".$link->connect_errno.") ".$link->connect_error;
}


?>