<html>
<head>
    <title>Cadastro concluido</title>
    </head>

    <body>


<?php 
include("../blog/cadastro.php");


$titulo =$_POST['titulo'];
$corpo =$_POST['corpo'];



        $result = mysqli_query( $link, $sql ) or die ('Error querying database.');

         
?>

  <h1>Seu cadastro foi enviado, parabéns!!!</h1>
    </body>

</html>